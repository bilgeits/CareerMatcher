package com.careermatcher.career_quiz.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class QuizController {

    @GetMapping("/")
    public String home() {
        return "index"; // index.html şablonuna yönlendirir
    }

    @GetMapping("/quiz")
    public String quizForm(Model model) {
        model.addAttribute("result", null);
        return "quiz"; // quiz.html sayfasını render eder
    }

    @PostMapping("/quiz")
    public String submitQuiz(@RequestParam int skill,
                             @RequestParam int time,
                             @RequestParam int interest,
                             Model model) {

        String result = matchCareer(skill, time, interest);
        model.addAttribute("result", result);
        return "quiz";
    }

    private String matchCareer(int skill, int time, int interest) {
        if (interest == 1 && skill == 1) return "Software Developer";
        else if (interest == 2 && skill == 3) return "Graphic Designer";
        else if (interest == 3 && skill == 4) return "Therapist";
        else if (interest == 4 && skill == 2) return "Marketing Specialist";
        else return "Freelancer or Entrepreneur";
    }
}

