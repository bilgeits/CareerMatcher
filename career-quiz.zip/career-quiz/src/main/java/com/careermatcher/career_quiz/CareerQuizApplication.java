package com.careermatcher.career_quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerQuizApplication.class, args);
	}

}
