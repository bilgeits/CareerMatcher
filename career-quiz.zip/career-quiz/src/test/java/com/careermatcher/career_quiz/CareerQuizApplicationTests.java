package com.careermatcher.career_quiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
